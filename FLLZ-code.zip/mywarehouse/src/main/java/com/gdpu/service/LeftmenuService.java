package com.gdpu.service;

import com.gdpu.bean.Leftmenu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author
 * @since 2020-06-30
 */
public interface LeftmenuService extends IService<Leftmenu> {

}
