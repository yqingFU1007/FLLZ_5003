package com.gdpu.service;

import com.gdpu.bean.Provider;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author
 * @since 2020-06-29
 */
public interface ProviderService extends IService<Provider> {

}
