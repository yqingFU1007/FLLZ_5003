package com.gdpu.service;

import com.gdpu.bean.Customer;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author
 * @since 2020-07-02
 */
public interface CustomerService extends IService<Customer> {

}
