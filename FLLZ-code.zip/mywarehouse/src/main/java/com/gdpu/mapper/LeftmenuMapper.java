package com.gdpu.mapper;

import com.gdpu.bean.Leftmenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author
 * @since 2020-06-30
 */
public interface LeftmenuMapper extends BaseMapper<Leftmenu> {

}
