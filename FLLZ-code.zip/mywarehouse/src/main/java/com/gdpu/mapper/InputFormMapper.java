package com.gdpu.mapper;

import com.gdpu.bean.InputForm;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author
 * @since 2020-07-02
 */
public interface InputFormMapper extends BaseMapper<InputForm> {

}
