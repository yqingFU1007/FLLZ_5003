/*
 Navicat Premium Data Transfer

 Source Server         : 本地mysql8.0.33
 Source Server Type    : MySQL
 Source Server Version : 80033
 Source Host           : localhost:3306
 Source Schema         : mywarehouse

 Target Server Type    : MySQL
 Target Server Version : 80033
 File Encoding         : 65001

 Date: 28/05/2024 21:17:51
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `customer_id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `manager` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tale_phone` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`customer_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (1, 'Bai Ge Supermarket', 'Guangdong Province, Guangzhou City, Tianhe District, xxxx111', 'Li Laoba', '13578945611');
INSERT INTO `customer` VALUES (2, 'JD Mall', 'Guangdong Province, Guangzhou City, Tianhe District, xxxx', 'Pigeon1', '13507521234');
INSERT INTO `customer` VALUES (3, 'Tmall Supermarket', 'Guangdong Province, Dongguan City, xxxx', 'Zhang San', '13566664520');
INSERT INTO `customer` VALUES (4, 'Zhang San', 'Lujiazui, Shanghai', 'Zhang San', '11111111111');

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods`  (
  `goods_id` int(0) NOT NULL AUTO_INCREMENT COMMENT 'Goods ID',
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'Goods Name',
  `provider_id` int(0) NULL DEFAULT NULL COMMENT 'Supplier ID',
  `price` int(0) NULL DEFAULT NULL COMMENT 'Price',
  `size` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Specification',
  `packages` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Packaging',
  PRIMARY KEY (`goods_id`, `name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES (1, 'Coca-Cola', 1, 43, '330ml/bottle', '24 bottles/box');
INSERT INTO `goods` VALUES (2, 'Pepsi', 1, 42, '330ml/bottle', '24 bottles/box');
INSERT INTO `goods` VALUES (3, 'Sprite', 2, 44, '330ml/bottle', '24 bottles/box');
INSERT INTO `goods` VALUES (4, 'Mirinda', 4, 42, '330ml/bottle', '24 bottles/box');
INSERT INTO `goods` VALUES (5, 'Budweiser', 2, 88, '330ml/bottle', '24 bottles/box');
INSERT INTO `goods` VALUES (6, 'Biquan', 3, 66, '330ml/bottle', '24 bottles/box');
INSERT INTO `goods` VALUES (7, 'Qoo', 3, 60, '330ml/bottle', '24 bottles/box');
INSERT INTO `goods` VALUES (8, 'Fanta', 3, 44, '330ml/bottle', '24 bottles/box');

-- ----------------------------
-- Table structure for input_form
-- ----------------------------
DROP TABLE IF EXISTS `input_form`;
CREATE TABLE `input_form`  (
  `form_id` int(0) NOT NULL AUTO_INCREMENT,
  `provider_id` int(0) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `goods_id` int(0) NULL DEFAULT NULL,
  `house_id` int(0) NULL DEFAULT NULL,
  `change_number` int(0) NULL DEFAULT NULL,
  `user_id` int(0) NULL DEFAULT NULL COMMENT 'Person in charge',
  PRIMARY KEY (`form_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of input_form
-- ----------------------------
INSERT INTO `input_form` VALUES (1, 1, '2020-07-02 00:00:00', 1, 1, 1, 1);
INSERT INTO `input_form` VALUES (3, 1, '2020-07-02 08:08:05', 1, 2, 1000, 2);
INSERT INTO `input_form` VALUES (4, 3, '2020-07-02 08:08:57', 5, 3, 123, 2);
INSERT INTO `input_form` VALUES (5, 3, '2020-07-02 08:10:09', 8, 2, 123, 2);
INSERT INTO `input_form` VALUES (6, 1, '2020-07-02 08:10:19', 3, 3, 555, 2);
INSERT INTO `input_form` VALUES (7, 2, '2020-07-02 08:10:27', 7, 2, 444, 2);
INSERT INTO `input_form` VALUES (8, 3, '2020-07-02 08:10:35', 6, 3, 444, 2);
INSERT INTO `input_form` VALUES (10, 3, '2020-07-02 08:10:52', 7, 3, 5555, 2);
INSERT INTO `input_form` VALUES (12, 1, '2020-07-02 08:17:33', 2, 2, 50, 2);
INSERT INTO `input_form` VALUES (13, 1, '2020-07-02 08:18:34', 2, 2, 555, 2);
INSERT INTO `input_form` VALUES (14, 3, '2020-07-02 15:38:50', 7, 3, 2000, 2);
INSERT INTO `input_form` VALUES (15, 3, '2020-07-02 15:43:55', 7, 3, 2000, 2);
INSERT INTO `input_form` VALUES (16, 1, '2020-07-03 14:29:33', 4, 4, 20, 2);
INSERT INTO `input_form` VALUES (17, 4, '2020-07-03 15:05:52', 4, 3, 20, 2);
INSERT INTO `input_form` VALUES (18, 1, '2020-07-03 15:06:46', 1, 1, 500, 2);

-- ----------------------------
-- Table structure for leftmenu
-- ----------------------------
DROP TABLE IF EXISTS `leftmenu`;
CREATE TABLE `leftmenu`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `pid` int(0) NULL DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `href` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `open` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 128 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of leftmenu
-- ----------------------------
INSERT INTO `leftmenu` VALUES (1, 0, 'Warehouse Management System', '&#xe68e;', '', 1);
INSERT INTO `leftmenu` VALUES (2, 1, 'Basic Management', '&#xe857;', '', 0);
INSERT INTO `leftmenu` VALUES (3, 1, 'Warehouse Management', '&#xe645;', '', 1);
INSERT INTO `leftmenu` VALUES (4, 1, 'System Management', '&#xe614;', '', 0);
INSERT INTO `leftmenu` VALUES (5, 2, 'Customer Management', '&#xe66f;', '/sys/toCustomerManager', 0);
INSERT INTO `leftmenu` VALUES (6, 2, 'Supplier Management', '&#xe698;', '/sys/toProviderManager', 0);
INSERT INTO `leftmenu` VALUES (8, 3, 'Inbound', '&#xe65b;', '/sys/toInputManager', 0);
INSERT INTO `leftmenu` VALUES (9, 3, 'Outbound', '&#xe65a;', '/sys/toOutputManager', 0);
INSERT INTO `leftmenu` VALUES (17, 4, 'Role Management', '&#xe650;', '/sys/toRoleManager', 0);
INSERT INTO `leftmenu` VALUES (18, 4, 'User Management', '&#xe612;', '/sys/toUserManager', 0);
INSERT INTO `leftmenu` VALUES (126, 2, 'Product Management', '&#xe658;', '/sys/toGoodsManager', 0);
INSERT INTO `leftmenu` VALUES (127, 3, 'Warehouse Basic Settings', '&#xe716;', '/sys/toWarehouseManager', 0);

-- ----------------------------
-- Table structure for output_form
-- ----------------------------
DROP TABLE IF EXISTS `output_form`;
CREATE TABLE `output_form`  (
  `form_id` int(0) NOT NULL AUTO_INCREMENT,
  `customer_id` int(0) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `goods_id` int(0) NULL DEFAULT NULL,
  `house_id` int(0) NULL DEFAULT NULL,
  `change_number` int(0) NULL DEFAULT NULL,
  `user_id` int(0) NULL DEFAULT NULL COMMENT 'Person in charge',
  PRIMARY KEY (`form_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of output_form
-- ----------------------------
INSERT INTO `output_form` VALUES (1, 1, '2020-07-02 00:00:00', 1, 1, 1000, 1);
INSERT INTO `output_form` VALUES (2, 2, '2020-07-03 02:51:18', 4, 2, 2000, 2);
INSERT INTO `output_form` VALUES (3, 2, '2020-07-03 04:48:39', 4, 1, 1, 2);
INSERT INTO `output_form` VALUES (4, 3, '2020-07-03 04:53:47', 4, 1, 20, 2);
INSERT INTO `output_form` VALUES (5, 2, '2020-07-03 04:54:05', 4, 1, 20, 2);
INSERT INTO `output_form` VALUES (6, 2, '2020-07-03 04:54:59', 6, 2, 20, 2);
INSERT INTO `output_form` VALUES (7, 2, '2020-07-03 04:55:09', 7, 3, 20, 2);
INSERT INTO `output_form` VALUES (8, 3, '2020-07-03 04:55:22', 6, 3, 20, 2);
INSERT INTO `output_form` VALUES (9, 2, '2020-07-03 09:50:33', 2, 2, 20, 7);
INSERT INTO `output_form` VALUES (10, 3, '2020-07-03 11:29:53', 6, 2, 20, 7);
INSERT INTO `output_form` VALUES (11, 1, '2023-05-06 09:17:39', 5, 1, 11, 1);

-- ----------------------------
-- Table structure for provider
-- ----------------------------
DROP TABLE IF EXISTS `provider`;
CREATE TABLE `provider` (
  `provider_id` int(0) NOT NULL AUTO_INCREMENT COMMENT 'Supplier ID',
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Supplier Name',
  `address` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Address',
  `manager` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Manager',
  `tale_phone` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Manager Phone',
  PRIMARY KEY (`provider_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of provider
-- ----------------------------
INSERT INTO `provider` VALUES (1, 'Huizhou Beverage Supplier', 'XXX, Huicheng District, Huizhou City, Guangdong Province', 'Zhang San', '13533331234');
INSERT INTO `provider` VALUES (2, 'Guangzhou Beverage Supplier', 'XXXX, Tianhe District, Guangzhou City, Guangdong Province', 'Li Si', '13522221234');
INSERT INTO `provider` VALUES (3, 'Dongguan Beverage Supplier', 'XXX, Dongguan City, Guangdong Province', 'Wang Wu', '13511111234');
INSERT INTO `provider` VALUES (4, 'New Beverage Supplier', 'Santiago, Hebei Province', 'I Came to Hebei Province', '13512345678');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `role_id` int(0) NOT NULL AUTO_INCREMENT COMMENT 'Role ID',
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Role Name',
  `remark` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Remarks',
  `available` int(0) NULL DEFAULT NULL COMMENT 'Availability',
  `createtime` datetime(0) NULL DEFAULT NULL COMMENT 'Creation Time',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, 'Super Administrator', 'Has permissions for all menus', 1, '2020-06-29 00:00:00');
INSERT INTO `role` VALUES (2, 'Warehouse Manager No.1', 'Can operate Warehouse No.1', 1, '2020-06-29 00:00:00');
INSERT INTO `role` VALUES (3, 'Warehouse Manager No.2', 'Can operate Warehouse No.2', 1, '2020-06-29 00:00:00');
INSERT INTO `role` VALUES (4, 'Warehouse Manager No.3', 'Can operate Warehouse No.3', 1, '2020-06-29 00:00:00');
INSERT INTO `role` VALUES (5, 'Warehouse Manager No.4', 'Warehouse Manager No.4', 0, '2020-07-02 14:50:14');
INSERT INTO `role` VALUES (6, 'Warehouse Manager No.5', 'Can operate Warehouse No.5', 0, '2020-06-29 00:00:00');
INSERT INTO `role` VALUES (7, 'Warehouse Manager No.6', 'Warehouse Manager No.6', 1, '2024-04-22 23:58:45');

-- ----------------------------
-- Table structure for stock
-- ----------------------------
DROP TABLE IF EXISTS `stock`;
CREATE TABLE `stock`  (
  `goods_id` int(0) NOT NULL,
  `house_id` int(0) NOT NULL,
  `number` int(0) NULL DEFAULT NULL,
  `upper_alert` int(0) NULL DEFAULT NULL,
  `under_alert` int(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of stock
-- ----------------------------
INSERT INTO `stock` VALUES (5, 1, 4989, 10009, 3000);
INSERT INTO `stock` VALUES (2, 3, 5000, 7000, 3000);
INSERT INTO `stock` VALUES (3, 3, 5000, 10000, 3000);
INSERT INTO `stock` VALUES (1, 1, 5520, 10000, 3000);
INSERT INTO `stock` VALUES (6, 3, 4980, 10000, 3000);
INSERT INTO `stock` VALUES (7, 3, 4980, 10000, 3000);
INSERT INTO `stock` VALUES (5, 2, 5000, 10000, 3000);
INSERT INTO `stock` VALUES (6, 2, 4960, 10000, 3000);
INSERT INTO `stock` VALUES (2, 2, 4980, 10000, 3000);
INSERT INTO `stock` VALUES (4, 1, 4959, 10000, 3000);
INSERT INTO `stock` VALUES (0, 4, 0, 10000, 0);
INSERT INTO `stock` VALUES (0, 5, 0, 10000, 0);
INSERT INTO `stock` VALUES (0, 1, 0, 10000, 0);
INSERT INTO `stock` VALUES (0, 2, 0, 10000, 0);
INSERT INTO `stock` VALUES (0, 3, 0, 10000, 0);
INSERT INTO `stock` VALUES (4, 4, 20, 10000, 0);
INSERT INTO `stock` VALUES (4, 5, 20, 10000, 0);
INSERT INTO `stock` VALUES (4, 3, 20, 10000, 0);

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user`  (
  `user_id` int(0) NOT NULL AUTO_INCREMENT,
  `role_id` int(0) NULL DEFAULT NULL,
  `account` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `age` int(0) NULL DEFAULT NULL,
  `sex` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `salt` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES (1, 1, 'admin', '532ac00e86893901af5f0be6b704dbc7', '111', 22, 'Male', '04A93C74C8294AA09A8B974FD1F4ECBB');
INSERT INTO `tb_user` VALUES (2, 1, 'Qian Duoduo', '532ac00e86893901af5f0be6b704dbc7', 'Qian Duoduo', 30, 'Male', '04A93C74C8294AA09A8B974FD1F4ECBB');
INSERT INTO `tb_user` VALUES (3, 2, 'ckgly', '532ac00e86893901af5f0be6b704dbc7', 'Warehouse Manager No.1', 22, 'Male', '04A93C74C8294AA09A8B974FD1F4ECBB');
INSERT INTO `tb_user` VALUES (4, 3, 'lx', '532ac00e86893901af5f0be6b704dbc7', 'lx', 22, 'Male', '04A93C74C8294AA09A8B974FD1F4ECBB');
INSERT INTO `tb_user` VALUES (5, 4, 'cym', '532ac00e86893901af5f0be6b704dbc7', 'cym', 22, 'Male', '04A93C74C8294AA09A8B974FD1F4ECBB');
INSERT INTO `tb_user` VALUES (6, 4, 'Zheng Chuangjian', '532ac00e86893901af5f0be6b704dbc7', 'Zheng Chuangjian', 22, 'Male', '04A93C74C8294AA09A8B974FD1F4ECBB');
INSERT INTO `tb_user` VALUES (7, 3, 'Lao Gan Ma', '532ac00e86893901af5f0be6b704dbc7', 'Lao Gan Ma', 60, 'Female', '04A93C74C8294AA09A8B974FD1F4ECBB');
INSERT INTO `tb_user` VALUES (9, 3, 'Add Test', '532ac00e86893901af5f0be6b704dbc7', 'hhh', 23, 'Female', 'E6E2CC1D172D42D7B5949FEDF1C8C00F');

-- ----------------------------
-- Table structure for warehouse
-- ----------------------------
DROP TABLE IF EXISTS `warehouse`;
CREATE TABLE `warehouse`  (
  `house_id` int(0) NOT NULL,
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`house_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of warehouse
-- ----------------------------
INSERT INTO `warehouse` VALUES (1, 'Huizhou Warehouse', '123 Warehouse, Pingshan Town,  Huizhou City, Guangdong Province');
INSERT INTO `warehouse` VALUES (2, 'Guangzhou Warehouse', 'Warehouse, University Town,  Guangzhou City, Guangdong Province');
INSERT INTO `warehouse` VALUES (3, 'Dongguan Warehouse', 'Warehouse, Dongguan City, Guangdong Province');
INSERT INTO `warehouse` VALUES (4, 'San Diego 2', 'San Diego Branch No. 2, Hebei Province');
INSERT INTO `warehouse` VALUES (5, 'San Diego 3', 'San Diego Branch No. 3, Hebei Province');

SET FOREIGN_KEY_CHECKS = 1;
